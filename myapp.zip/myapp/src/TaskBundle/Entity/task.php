<?php

namespace TaskBundle\Entity;

/**
 * task
 */
class task
{
    /**
     * @var int
     */
    private $id;

    /**
     * @var string
     */
    private $taskname;

    /**
     * @var string
     */
    private $taskdescription;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set taskname
     *
     * @param string $taskname
     *
     * @return task
     */
    public function setTaskname($taskname)
    {
        $this->taskname = $taskname;

        return $this;
    }

    /**
     * Get taskname
     *
     * @return string
     */
    public function getTaskname()
    {
        return $this->taskname;
    }

    /**
     * Set taskdescription
     *
     * @param string $taskdescription
     *
     * @return task
     */
    public function setTaskdescription($taskdescription)
    {
        $this->taskdescription = $taskdescription;

        return $this;
    }

    /**
     * Get taskdescription
     *
     * @return string
     */
    public function getTaskdescription()
    {
        return $this->taskdescription;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     *
     * @return task
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return task
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}

