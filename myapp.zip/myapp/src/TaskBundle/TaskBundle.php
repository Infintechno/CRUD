<?php

namespace TaskBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TaskBundle extends Bundle
{
}
