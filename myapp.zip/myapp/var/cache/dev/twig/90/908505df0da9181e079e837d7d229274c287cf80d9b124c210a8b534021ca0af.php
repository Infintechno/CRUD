<?php

/* base.html.twig */
class __TwigTemplate_3d2270665405f18967aa3e0ff922a8f24ba88b92a01fa3cc8d89775876f16c52 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

        <style>
            .hh2 {
    text-transform: uppercase;
    font-size: 28px;
    font-weight: 600;
    padding-bottom: 20px;
}
h1.hh2.h2-divide {
    border-bottom: 1px solid #eee;
    margin-bottom: 30px;
}
.table ul li {
    list-style: none;
    display: inline-block;
    margin-right: 10px;
}
.table ul{padding:0px; margin:0;}
table tr td {
    vertical-align: middle !important;
}
table.table ul li a {
    background: #eee;
    color: #222;
    display: block;
    padding: 9px 15px;
    border-radius: 10px;
}
a.btn-cmn {
    background: #222;
    color: #fff;
    display: inline-block;
    padding: 10px 30px;
    text-transform: uppercase;
    border-radius: 10px;
    border: 2px solid rgba(0,0,0,0);
    transition: 0.3s;
}
a.btn-cmn:hover {
    background: #fff;
    color: #222;
   text-decoration:none;
   
    border: 2px solid rgba(0,0,0,1);
    transition: 0.3s;
}
div#taskbundle_task_updatedAt {
    display: inline-block;
}
div#taskbundle_task_createdAt {
    display: inline-block;
}
.form-outer label:first-child {
    min-width: 130px;
    margin-bottom: 20px;
}
div#taskbundle_task_updatedAt_time {
    display: inline-block;
    margin-left: 10px;
}
.form-outer select {
    margin-left: 10px;
    height: 32px;
    padding: 0 10px;
    margin-bottom: 10px;
}
div#taskbundle_task_updatedAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_time {
    display: inline-block;
}
.form-outer input[type=\"text\"],.form-outer input[type=\"email\"],.form-outer input[type=\"password\"] {
    height: 32px;
    margin-left: 10px;
}
.form-outer {
    display: inline-block;
    padding: 30px 30px;
    margin-bottom: 40px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.4);
    border-radius: 30px;
}
.form-outer input.btn-cmn,.form-outer button.btn-cmn {
    background: #222;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 40px;
    margin-top: 10px;
    border-radius: 8px;
}
ul.custom-buttons li {
    list-style: none;
    display: inline-block;
    margin-right: 15px;
    margin-top: 10px;
}
ul.custom-buttons li a {
    color: #222;
    display: block;
    padding: 10px 15px;
    background: #ccc;
    border-radius: 10px;
}
.custom-buttons{padding:0;}
.custom-buttons li input[type=\"submit\"] {
    background: #960f0f;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 30px;
    border-radius: 10px;
}
            </style>
            
            <!--<link rel=\"stylesheet\" href=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/webshome/css/main.css"), "html", null, true);
        echo "\">-->
</head>
    <body>
\t   <div>
            ";
        // line 133
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 134
            echo "                Welcome ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " |
                <a href=\"";
            // line 135
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 136
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
            ";
        } else {
            // line 139
            echo "\t\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
\t\t\t<script>window.location.href =\"http://localhost/myapp/web/app_dev.php/login\"</script>
                <!--<a href=\"";
            // line 141
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>-->
            ";
        }
        // line 143
        echo "        </div>
\t\t
        ";
        // line 145
        $this->displayBlock('body', $context, $blocks);
        // line 146
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 147
        echo "        
        
        <!-- jQuery library -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 145
    public function block_body($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 146
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  282 => 146,  265 => 145,  248 => 6,  230 => 5,  211 => 147,  208 => 146,  206 => 145,  202 => 143,  195 => 141,  191 => 139,  185 => 136,  181 => 135,  176 => 134,  174 => 133,  167 => 129,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

        <style>
            .hh2 {
    text-transform: uppercase;
    font-size: 28px;
    font-weight: 600;
    padding-bottom: 20px;
}
h1.hh2.h2-divide {
    border-bottom: 1px solid #eee;
    margin-bottom: 30px;
}
.table ul li {
    list-style: none;
    display: inline-block;
    margin-right: 10px;
}
.table ul{padding:0px; margin:0;}
table tr td {
    vertical-align: middle !important;
}
table.table ul li a {
    background: #eee;
    color: #222;
    display: block;
    padding: 9px 15px;
    border-radius: 10px;
}
a.btn-cmn {
    background: #222;
    color: #fff;
    display: inline-block;
    padding: 10px 30px;
    text-transform: uppercase;
    border-radius: 10px;
    border: 2px solid rgba(0,0,0,0);
    transition: 0.3s;
}
a.btn-cmn:hover {
    background: #fff;
    color: #222;
   text-decoration:none;
   
    border: 2px solid rgba(0,0,0,1);
    transition: 0.3s;
}
div#taskbundle_task_updatedAt {
    display: inline-block;
}
div#taskbundle_task_createdAt {
    display: inline-block;
}
.form-outer label:first-child {
    min-width: 130px;
    margin-bottom: 20px;
}
div#taskbundle_task_updatedAt_time {
    display: inline-block;
    margin-left: 10px;
}
.form-outer select {
    margin-left: 10px;
    height: 32px;
    padding: 0 10px;
    margin-bottom: 10px;
}
div#taskbundle_task_updatedAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_time {
    display: inline-block;
}
.form-outer input[type=\"text\"],.form-outer input[type=\"email\"],.form-outer input[type=\"password\"] {
    height: 32px;
    margin-left: 10px;
}
.form-outer {
    display: inline-block;
    padding: 30px 30px;
    margin-bottom: 40px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.4);
    border-radius: 30px;
}
.form-outer input.btn-cmn,.form-outer button.btn-cmn {
    background: #222;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 40px;
    margin-top: 10px;
    border-radius: 8px;
}
ul.custom-buttons li {
    list-style: none;
    display: inline-block;
    margin-right: 15px;
    margin-top: 10px;
}
ul.custom-buttons li a {
    color: #222;
    display: block;
    padding: 10px 15px;
    background: #ccc;
    border-radius: 10px;
}
.custom-buttons{padding:0;}
.custom-buttons li input[type=\"submit\"] {
    background: #960f0f;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 30px;
    border-radius: 10px;
}
            </style>
            
            <!--<link rel=\"stylesheet\" href=\"{{ asset('bundles/webshome/css/main.css') }}\">-->
</head>
    <body>
\t   <div>
            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                Welcome {{ app.user.username }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'logout'|trans({}, 'FOSUserBundle') }}
                </a>
            {% else %}
\t\t\t<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>
\t\t\t<script>window.location.href =\"http://localhost/myapp/web/app_dev.php/login\"</script>
                <!--<a href=\"{{ path('fos_user_security_login') }}\">{{ 'login'|trans({}, 'FOSUserBundle') }}</a>-->
            {% endif %}
        </div>
\t\t
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
        
        
        <!-- jQuery library -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\myapp\\app\\Resources\\views\\base.html.twig");
    }
}
