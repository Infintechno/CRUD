<?php

/* @FOSUser/layout.html.twig */
class __TwigTemplate_73b012d721daa53d78cd60a40588f2358a6b6afb71b1179df9cde7ec18d96657 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
          <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

        <style>
            .hh2 {
    text-transform: uppercase;
    font-size: 28px;
    font-weight: 600;
    padding-bottom: 20px;
}
h1.hh2.h2-divide {
    border-bottom: 1px solid #eee;
    margin-bottom: 30px;
}
.table ul li {
    list-style: none;
    display: inline-block;
    margin-right: 10px;
}
.table ul{padding:0px; margin:0;}
table tr td {
    vertical-align: middle !important;
}
table.table ul li a {
    background: #eee;
    color: #222;
    display: block;
    padding: 9px 15px;
    border-radius: 10px;
}
a.btn-cmn {
    background: #222;
    color: #fff;
    display: inline-block;
    padding: 10px 30px;
    text-transform: uppercase;
    border-radius: 10px;
    border: 2px solid rgba(0,0,0,0);
    transition: 0.3s;
}
a.btn-cmn:hover {
    background: #fff;
    color: #222;
   text-decoration:none;
   
    border: 2px solid rgba(0,0,0,1);
    transition: 0.3s;
}
div#taskbundle_task_updatedAt {
    display: inline-block;
}
div#taskbundle_task_createdAt {
    display: inline-block;
}
.form-outer label:first-child {
    min-width: 130px;
    margin-bottom: 20px;
}
.form-outer.form-label-custom label:first-child {
    min-width: 170px;
}
div#taskbundle_task_updatedAt_time {
    display: inline-block;
    margin-left: 10px;
}
.form-outer select {
    margin-left: 10px;
    height: 32px;
    padding: 0 10px;
    margin-bottom: 10px;
}
div#taskbundle_task_updatedAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_time {
    display: inline-block;
}
.form-outer input[type=\"text\"],.form-outer input[type=\"email\"],.form-outer input[type=\"password\"] {
    height: 32px;
    margin-left: 10px;
}
.form-outer {
    display: inline-block;
    padding: 30px 30px;
    margin-bottom: 40px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.4);
    border-radius: 30px;
}
.form-outer input.btn-cmn,.form-outer button.btn-cmn {
    background: #222;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 40px;
    margin-top: 10px;
    border-radius: 8px;
}
.mar-50{margin-top:50px;}
ul.custom-buttons li {
    list-style: none;
    display: inline-block;
    margin-right: 15px;
    margin-top: 10px;
}
ul.custom-buttons li a {
    color: #222;
    display: block;
    padding: 10px 15px;
    background: #ccc;
    border-radius: 10px;
}
.custom-buttons{padding:0;}
.custom-buttons li input[type=\"submit\"] {
    background: #960f0f;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 30px;
    border-radius: 10px;
}
            </style>
    </head>
    <body>
        <div>
            ";
        // line 132
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 133
            echo "                <!--";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 134
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 135
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "-->
                </a>
            ";
        } else {
            // line 138
            echo "                <!--<a href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>-->
            ";
        }
        // line 140
        echo "        </div>

        ";
        // line 142
        if ($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "request", array()), "hasPreviousSession", array())) {
            // line 143
            echo "            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute(($context["app"] ?? $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 144
                echo "                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 145
                    echo "                   <!-- <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                        ";
                    // line 146
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                    </div>-->
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 149
                echo "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 150
            echo "        ";
        }
        // line 151
        echo "
        <div>
            ";
        // line 153
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 155
        echo "        </div>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    </body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 153
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 154
        echo "            ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  255 => 154,  246 => 153,  229 => 155,  227 => 153,  223 => 151,  220 => 150,  214 => 149,  205 => 146,  200 => 145,  195 => 144,  190 => 143,  188 => 142,  184 => 140,  176 => 138,  170 => 135,  166 => 134,  161 => 133,  159 => 132,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
          <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\">

        <style>
            .hh2 {
    text-transform: uppercase;
    font-size: 28px;
    font-weight: 600;
    padding-bottom: 20px;
}
h1.hh2.h2-divide {
    border-bottom: 1px solid #eee;
    margin-bottom: 30px;
}
.table ul li {
    list-style: none;
    display: inline-block;
    margin-right: 10px;
}
.table ul{padding:0px; margin:0;}
table tr td {
    vertical-align: middle !important;
}
table.table ul li a {
    background: #eee;
    color: #222;
    display: block;
    padding: 9px 15px;
    border-radius: 10px;
}
a.btn-cmn {
    background: #222;
    color: #fff;
    display: inline-block;
    padding: 10px 30px;
    text-transform: uppercase;
    border-radius: 10px;
    border: 2px solid rgba(0,0,0,0);
    transition: 0.3s;
}
a.btn-cmn:hover {
    background: #fff;
    color: #222;
   text-decoration:none;
   
    border: 2px solid rgba(0,0,0,1);
    transition: 0.3s;
}
div#taskbundle_task_updatedAt {
    display: inline-block;
}
div#taskbundle_task_createdAt {
    display: inline-block;
}
.form-outer label:first-child {
    min-width: 130px;
    margin-bottom: 20px;
}
.form-outer.form-label-custom label:first-child {
    min-width: 170px;
}
div#taskbundle_task_updatedAt_time {
    display: inline-block;
    margin-left: 10px;
}
.form-outer select {
    margin-left: 10px;
    height: 32px;
    padding: 0 10px;
    margin-bottom: 10px;
}
div#taskbundle_task_updatedAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_date {
    display: inline-block;
}
div#taskbundle_task_createdAt_time {
    display: inline-block;
}
.form-outer input[type=\"text\"],.form-outer input[type=\"email\"],.form-outer input[type=\"password\"] {
    height: 32px;
    margin-left: 10px;
}
.form-outer {
    display: inline-block;
    padding: 30px 30px;
    margin-bottom: 40px;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.4);
    border-radius: 30px;
}
.form-outer input.btn-cmn,.form-outer button.btn-cmn {
    background: #222;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 40px;
    margin-top: 10px;
    border-radius: 8px;
}
.mar-50{margin-top:50px;}
ul.custom-buttons li {
    list-style: none;
    display: inline-block;
    margin-right: 15px;
    margin-top: 10px;
}
ul.custom-buttons li a {
    color: #222;
    display: block;
    padding: 10px 15px;
    background: #ccc;
    border-radius: 10px;
}
.custom-buttons{padding:0;}
.custom-buttons li input[type=\"submit\"] {
    background: #960f0f;
    border: none;
    color: #fff;
    text-transform: uppercase;
    padding: 10px 30px;
    border-radius: 10px;
}
            </style>
    </head>
    <body>
        <div>
            {% if is_granted(\"IS_AUTHENTICATED_REMEMBERED\") %}
                <!--{{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |
                <a href=\"{{ path('fos_user_security_logout') }}\">
                    {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}-->
                </a>
            {% else %}
                <!--<a href=\"{{ path('fos_user_security_login') }}\">{{ 'login'|trans({}, 'FOSUserBundle') }}</a>-->
            {% endif %}
        </div>

        {% if app.request.hasPreviousSession %}
            {% for type, messages in app.session.flashbag.all() %}
                {% for message in messages %}
                   <!-- <div class=\"flash-{{ type }}\">
                        {{ message }}
                    </div>-->
                {% endfor %}
            {% endfor %}
        {% endif %}

        <div>
            {% block fos_user_content %}
            {% endblock fos_user_content %}
        </div>
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>

<!-- Latest compiled JavaScript -->
<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    </body>
</html>
", "@FOSUser/layout.html.twig", "C:\\xampp\\htdocs\\myapp\\vendor\\friendsofsymfony\\user-bundle\\Resources\\views\\layout.html.twig");
    }
}
